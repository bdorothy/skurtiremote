addon-multi-location-settings-manager
=====================================

This add-on changes CartThrob settings based on country of origin. It will use ip2nation if no other customer location data is found

Installation: move file to system > expressionengine > third_party 

This add-on is provided as-is at no cost with no warranty expressed or implied. Support is not included. 