<?php

$config['cartthrob_multi_location_default_settings']  = array(
	'other'		=> array(),
	'fields'		=> array(),
	'location_field'	=> array(),
	'configuration_settings'	=> array(),
); 
 